$(document).ready(function(){

	$('#nav-icon').click(function(){
		$(this).toggleClass('open');
    $('.fullscreen-nav').toggleClass('open');
	});
});